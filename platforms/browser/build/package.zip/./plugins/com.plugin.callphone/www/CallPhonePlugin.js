cordova.define("com.plugin.callphone.CallPhonePlugin", function(require, exports, module) { var exec = require('cordova/exec');
//exports.coolMethod = function(arg0, success, error) {
//    exec(success, error, "CallPhonePlugin", "coolMethod", [arg0]);
//};

exports.call = function(phoneNumber){
    exec(success, error, "CallPhonePlugin", "call", [phoneNumber]);
}

var CallPhonePlugin = {}

CallPhonePlugin.call = function(phoneNumber) {
    exec(success, error, "CallPhonePlugin", "call", [phoneNumber]);
}

window.CallPhonePlugin = CallPhonePlugin
});
